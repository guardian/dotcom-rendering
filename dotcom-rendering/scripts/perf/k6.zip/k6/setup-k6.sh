systemctl stop article
chmod +x ./k6-install.sh
./k6-install.sh
